#programa para rodar a segunda parte da análise

import pandas as pd
import numpy as np 
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def c(tensao,tempo):
	tensao = str(tensao)
	tempo = str(tempo)
	data = np.loadtxt(f'c2-{tensao}-{tempo}.txt', skiprows = 1, dtype=np.str)
	data2 = np.char.replace(data, ',', '.').astype(np.float)
	data3 = pd.DataFrame(data2, columns=['angle','count'])
	energy = 12.4/(5.64*np.sin(data3['angle']*np.pi/180))
	data3.insert(1,'energy',energy,True)
	
	if tempo == '5':
		sigma = np.sqrt(5*data3['count'])/5
		data3.insert(3,'sigma',sigma,True)
	else:
		sigma2 = np.sqrt(data3['count'])
		data3.insert(3,'sigma',sigma2,True)
	
	return(data3)
	
def gauss(x, a, x0, sig):  #a=ymax, x0=centro da curva, sigma=largura da curva
    return a*np.exp(-(x-x0)**2/(2*sig**2))
    
def main():
	
	ddp = int(input('Qual a tensão? '))
	time = int(input('Qual o tempo de exposição? '))
	c1 = c(ddp, time)
	
	# dados de x, y e sigma para kbeta
	c1xb = c1['energy'][(c1['angle'] >= 6.1) & (c1['angle'] <= 6.6)]
	c1yb = c1['count'][(c1['angle'] >= 6.1) & (c1['angle'] <= 6.6)]
	c1sigb = c1['sigma'][(c1['angle'] >= 6.1) & (c1['angle'] <= 6.6)]
	
	#dados de x, y e sigma para kalpha
	c1xa = c1['energy'][(c1['angle'] >= 6.9) & (c1['angle'] <= 7.6)]
	c1ya = c1['count'][(c1['angle'] >= 6.9) & (c1['angle'] <= 7.6)]
	c1siga = c1['sigma'][(c1['angle'] >= 6.9) & (c1['angle'] <= 7.6)]
	
	# usando o curve_fit para kb
	
	popt, pcov = curve_fit(gauss, c1xb, c1yb, sigma = c1sigb, p0=[900,20,1])
	a = popt[0]
	x0 = popt[1] 
	sigma = popt[2]
	
	xx = np.linspace(19,20.7,2000)
	xx2 = np.linspace(16.5,18.5,2000)
	
	popt2, pcov2 = curve_fit(gauss, c1xa, c1ya, sigma = c1siga, p0=[1500,17.5,0.8])
	a2 = popt2[0]
	x02 = popt2[1] 
	sigma2 = popt2[2]
	
	fig, (ax1, ax2) = plt.subplots(2)
	
	ax1.scatter(c1xb, c1yb,label = r'K$_\beta$ Experimetal', marker = '.')
	ax1.plot(xx, gauss(xx,*popt),color='red',label=r'K$_\beta$ Ajustado')
	ax1.errorbar(c1xb, c1yb, yerr = c1sigb, xerr = 0.05)
	ax1.set_title(fr'K$_\beta$ e K$_\alpha$ - Exposição de {time}s - Tensão de {ddp} kV')
	ax1.set(ylabel = r'Intensidade (s$^{-1}$)')
	ax1.legend()
	

	ax2.scatter(c1xa, c1ya, label = r'K$_\alpha$ Experimetal', marker = '.')
	ax2.plot(xx2, gauss(xx2,*popt2),color = 'red', label = r'K$_\alpha$ Ajustado')
	ax2.errorbar(c1xa, c1ya, yerr = c1siga, xerr = 0.05)
	ax2.set(xlabel = 'Energia (keV)', ylabel = r'Intensidade (s$^{-1}$)')
	ax2.legend()
	
	print('aa =', a2,';',' meda (keV) =',x02,';','sigmaa = ',sigma2)
	print('ab =', a,';',' medb (keV) =',x0,';','sigmab = ',sigma)
	
	plt.show()

main()
